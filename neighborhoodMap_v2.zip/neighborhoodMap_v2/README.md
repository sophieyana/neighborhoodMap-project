# neighborhood map

### How to use the app?
* Open index.html in your browser.  
* To find a location in the map, use the input box or directly click on it.  
* Click on the marker to open an info window and get info about the place. Click on the link to get redirected to the Wikipedia page.
* Click on the hamburger icon to show/hide the menu.
